package com.anticheat.mixins;

import com.anticheat.AntiCheatMod;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractClientPlayerEntity.class)
public class MixinClientPlayerEntity {

    /**
     * Fires whenever a client-side player entity takes damage.
     * We use this to track attack timestamps on observed players.
     */
    @Inject(method = "damage", at = @At("HEAD"))
    private void onDamage(DamageSource source, float amount, CallbackInfo ci) {
        AbstractClientPlayerEntity self = (AbstractClientPlayerEntity)(Object) this;

        // If the attacker is another player (not the local player), record the attack
        Entity attacker = source.getAttacker();
        if (attacker instanceof AbstractClientPlayerEntity attackerPlayer) {
            if (AntiCheatMod.detectionManager != null) {
                AntiCheatMod.detectionManager.onPlayerAttack(
                    net.minecraft.client.MinecraftClient.getInstance(),
                    attackerPlayer
                );
            }
        }
    }
}
