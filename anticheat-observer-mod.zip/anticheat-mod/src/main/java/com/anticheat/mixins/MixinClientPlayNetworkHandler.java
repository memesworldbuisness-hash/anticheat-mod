package com.anticheat.mixins;

import com.anticheat.AntiCheatMod;
import com.anticheat.detectors.ScaffoldDetector;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class MixinClientPlayNetworkHandler {

    /**
     * Intercept outgoing block-place packets to track scaffold-style bridging.
     * This fires when THE LOCAL PLAYER places a block — we use this as a reference
     * only. For other players we observe world changes via tick loop.
     */
    @Inject(method = "sendPacket", at = @At("HEAD"))
    private void onSendPacket(net.minecraft.network.packet.Packet<?> packet, CallbackInfo ci) {
        if (packet instanceof PlayerInteractBlockC2SPacket) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;

            // Notify scaffold detector that a block was placed by local player
            // Other players' block placements are inferred from world state in tick loop
        }
    }
}
