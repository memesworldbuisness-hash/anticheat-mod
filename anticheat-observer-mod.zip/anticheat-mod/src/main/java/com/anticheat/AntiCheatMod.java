package com.anticheat;

import com.anticheat.managers.DetectionManager;
import com.anticheat.managers.PlayerDataManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AntiCheatMod implements ClientModInitializer {

    public static final String MOD_ID = "anticheat";
    public static final String MOD_NAME = "§c§lAntiCheat§r";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static DetectionManager detectionManager;
    public static PlayerDataManager playerDataManager;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[AntiCheat] Initializing AntiCheat Mod for Fabric 1.20.1");

        playerDataManager = new PlayerDataManager();
        detectionManager  = new DetectionManager(playerDataManager);

        // Tick every client frame
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.world != null && client.player != null) {
                detectionManager.tick(client);
            }
        });

        // Clear data on disconnect
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            playerDataManager.clearAll();
            LOGGER.info("[AntiCheat] Cleared player data on disconnect.");
        });

        LOGGER.info("[AntiCheat] Successfully initialized.");
    }
}
