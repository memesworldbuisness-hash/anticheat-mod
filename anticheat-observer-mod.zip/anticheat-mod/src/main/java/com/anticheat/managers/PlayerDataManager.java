package com.anticheat.managers;

import com.anticheat.utils.PlayerData;
import net.minecraft.client.network.AbstractClientPlayerEntity;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class PlayerDataManager {

    private final Map<UUID, PlayerData> playerMap = new ConcurrentHashMap<>();

    public PlayerData getOrCreate(AbstractClientPlayerEntity player) {
        return playerMap.computeIfAbsent(player.getUuid(),
                uuid -> new PlayerData(uuid, player.getName().getString()));
    }

    public PlayerData get(UUID uuid) {
        return playerMap.get(uuid);
    }

    public Collection<PlayerData> getAll() {
        return playerMap.values();
    }

    public void remove(UUID uuid) {
        playerMap.remove(uuid);
    }

    public void clearAll() {
        playerMap.clear();
    }

    public int size() {
        return playerMap.size();
    }
}
