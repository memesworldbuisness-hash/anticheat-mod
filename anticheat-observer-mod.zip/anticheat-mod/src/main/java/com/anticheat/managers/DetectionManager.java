package com.anticheat.managers;

import com.anticheat.detectors.*;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

import java.util.ArrayList;
import java.util.List;

public class DetectionManager {

    private final PlayerDataManager playerDataManager;
    private final List<BaseDetector> detectors = new ArrayList<>();

    public DetectionManager(PlayerDataManager playerDataManager) {
        this.playerDataManager = playerDataManager;

        // Register all detectors
        detectors.add(new FlyDetector());
        detectors.add(new SpeedDetector());
        detectors.add(new KillAuraDetector());
        detectors.add(new AimAssistDetector());
        detectors.add(new ReachDetector());
        detectors.add(new AutoClickerDetector());
        detectors.add(new HitDelayDetector());
        detectors.add(new NoFallDetector());
        detectors.add(new ScaffoldDetector());
        detectors.add(new JesusDetector());
        detectors.add(new NoKnockbackDetector());
    }

    public void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) return;

        for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
            // Skip the local player — we only check others
            if (player.equals(client.player)) continue;
            if (player.isRemoved()) continue;

            PlayerData data = playerDataManager.getOrCreate(player);

            // Run all detectors
            for (BaseDetector detector : detectors) {
                try {
                    detector.check(client, player, data);
                } catch (Exception e) {
                    // Silently swallow — never crash the client
                }
            }

            // Update position history AFTER detectors run (so detectors see the delta)
            data.updatePosition(player.getX(), player.getY(), player.getZ());
        }
    }

    /**
     * Called by the block-place mixin to notify the scaffold detector.
     */
    public void onBlockPlace(MinecraftClient client, AbstractClientPlayerEntity placer) {
        if (placer == null || placer.equals(client.player)) return;
        PlayerData data = playerDataManager.get(placer.getUuid());
        if (data != null) ScaffoldDetector.onBlockPlace(data);
    }

    /**
     * Called by the attack mixin when a player attacks another entity.
     */
    public void onPlayerAttack(MinecraftClient client, AbstractClientPlayerEntity attacker) {
        if (attacker == null || attacker.equals(client.player)) return;
        PlayerData data = playerDataManager.get(attacker.getUuid());
        if (data != null) data.recordAttack();
    }
}
