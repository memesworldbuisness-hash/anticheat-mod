package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

public class SpeedDetector extends BaseDetector {

    // Vanilla max sprint speed per tick (blocks)
    private static final double BASE_MAX_SPEED       = 0.2873; // ~20.7 b/s sprinting
    private static final double SPRINT_BOOST_PER_LVL = 0.062;  // per Speed effect level
    private static final double ICE_MULTIPLIER        = 1.8;
    private static final double LENIENCE              = 0.08;   // server lag tolerance

    public SpeedDetector() {
        super("Speed");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.hasVehicle())             return;
        if (player.isSpectator())            return;
        if (player.getAbilities().flying)    return;

        double deltaX = player.getX() - data.lastX;
        double deltaZ = player.getZ() - data.lastZ;
        double hSpeed = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);

        double maxAllowed = BASE_MAX_SPEED + LENIENCE;

        // Account for Speed potion effect
        if (player.hasStatusEffect(StatusEffects.SPEED)) {
            int amplifier = player.getStatusEffect(StatusEffects.SPEED).getAmplifier();
            maxAllowed += SPRINT_BOOST_PER_LVL * (amplifier + 1);
        }

        // Account for Slowness
        if (player.hasStatusEffect(StatusEffects.SLOWNESS)) {
            // Slowness reduces max, but players can't cheat under slowness normally
            // We still flag if way above vanilla
        }

        // Account for Soul Sand, ice blocks etc. — rough estimate: allow 2x on ice
        // We can't reliably detect block under feet client-side perfectly, so add padding
        maxAllowed += 0.05;

        data.lastDeltaXZ = hSpeed;

        if (hSpeed > maxAllowed) {
            data.speedViolations++;
            data.addFlag("Speed");

            if (data.canAlert("Speed")) {
                int sev = hSpeed > maxAllowed * 1.5 ? AlertUtils.HIGH : AlertUtils.MEDIUM;
                AlertUtils.sendAlert(client, data.name, "Speed",
                        String.format("spd=%.3f max=%.3f", hSpeed, maxAllowed),
                        sev, data.speedViolations);
            }
        } else {
            // Decay violations slowly
            if (data.speedViolations > 0) data.speedViolations--;
        }
    }
}
