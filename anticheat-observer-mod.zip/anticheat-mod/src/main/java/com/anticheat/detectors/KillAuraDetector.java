package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.MathUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

import java.util.*;

public class KillAuraDetector extends BaseDetector {

    // Max realistic snap between two ticks (degrees)
    private static final float  MAX_SNAP_YAW         = 180f;
    private static final float  MAX_SNAP_PITCH        = 90f;
    // Minimum time between legit hits (ms) — 1000ms / 20 ticks = 50ms minimum
    private static final long   MIN_ATTACK_INTERVAL_MS = 40;
    // Suspicious CPS threshold for attack rate
    private static final int    MAX_ATTACK_CPS        = 20;
    // Perfect rotation threshold — if rotation is identical multiple ticks it's suspicious
    private static final int    SAME_ROTATION_LIMIT   = 5;

    public KillAuraDetector() {
        super("KillAura");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.isSpectator()) return;

        float yaw   = player.getYaw();
        float pitch = player.getPitch();

        // --- Check 1: Snap rotation (instant yaw/pitch jumps) ---
        if (!data.rotationHistory.isEmpty()) {
            float[] last = data.rotationHistory.peekLast();
            float yawDiff   = MathUtils.yawDifference(yaw, last[0]);
            float pitchDiff = Math.abs(pitch - last[1]);

            // A snap that is very large AND happens right after an attack is suspicious
            boolean recentAttack = (System.currentTimeMillis() - data.lastAttackTime) < 100;
            if (recentAttack && yawDiff > 60f && yawDiff < MAX_SNAP_YAW) {
                data.killauraViolations++;
                data.addFlag("KillAura");
                if (data.canAlert("KillAura")) {
                    AlertUtils.sendAlert(client, data.name, "KillAura",
                            String.format("rotSnap yawΔ=%.1f°", yawDiff),
                            AlertUtils.MEDIUM, data.killauraViolations);
                }
            }

            // Perfect lock — same rotation every tick while attacking
            if (yawDiff < 0.001f && pitchDiff < 0.001f) {
                data.invalidRotationStreak++;
            } else {
                data.invalidRotationStreak = 0;
            }

            if (data.invalidRotationStreak >= SAME_ROTATION_LIMIT && recentAttack) {
                data.killauraViolations++;
                data.addFlag("KillAura");
                if (data.canAlert("KillAura")) {
                    AlertUtils.sendAlert(client, data.name, "KillAura",
                            String.format("perfectLock streak=%d", data.invalidRotationStreak),
                            AlertUtils.HIGH, data.killauraViolations);
                }
            }
        }

        data.addRotation(yaw, pitch);

        // --- Check 2: Attack rate (CPS on entities) ---
        if (!data.attackTimestamps.isEmpty()) {
            long now = System.currentTimeMillis();
            // Count attacks in last 1000ms
            long recentAttacks = data.attackTimestamps.stream()
                    .filter(t -> now - t <= 1000L)
                    .count();

            if (recentAttacks > MAX_ATTACK_CPS) {
                data.killauraViolations++;
                data.addFlag("KillAura");
                if (data.canAlert("KillAura")) {
                    AlertUtils.sendAlert(client, data.name, "KillAura",
                            String.format("attackCPS=%d max=%d", recentAttacks, MAX_ATTACK_CPS),
                            AlertUtils.HIGH, data.killauraViolations);
                }
            }

            // --- Check 3: Too-fast consecutive attacks ---
            if (data.attackTimestamps.size() >= 2) {
                Long[] times = data.attackTimestamps.toArray(new Long[0]);
                int susIntervals = 0;
                for (int i = 1; i < times.length; i++) {
                    long interval = times[i] - times[i - 1];
                    if (interval < MIN_ATTACK_INTERVAL_MS && interval > 0) {
                        susIntervals++;
                    }
                }
                if (susIntervals >= 3) {
                    data.killauraViolations++;
                    data.addFlag("KillAura");
                    if (data.canAlert("KillAura")) {
                        AlertUtils.sendAlert(client, data.name, "KillAura",
                                String.format("fastHit intervals<%dms x%d", MIN_ATTACK_INTERVAL_MS, susIntervals),
                                AlertUtils.MEDIUM, data.killauraViolations);
                    }
                }
            }
        }

        // --- Check 4: Multi-target aura (hitting multiple players very fast) ---
        // Handled in DetectionManager where we have context of all players
    }

    /**
     * Called by DetectionManager when it detects the player attacked while not facing target.
     */
    public static void flagMultiAura(MinecraftClient client, PlayerData data, double angle) {
        data.multiAuraViolations++;
        data.addFlag("MultiAura");
        if (data.canAlert("MultiAura")) {
            AlertUtils.sendAlert(client, data.name, "MultiAura",
                    String.format("hitAngle=%.1f°", angle),
                    AlertUtils.HIGH, data.multiAuraViolations);
        }
    }
}
