package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;

import java.util.List;

public class ReachDetector extends BaseDetector {

    // Vanilla survival reach = 3.0 blocks, creative = 4.5
    private static final double SURVIVAL_MAX_REACH = 3.2; // small buffer for ping
    private static final double CREATIVE_MAX_REACH = 4.7;
    private static final double FLAG_REACH         = 3.5; // flag above this in survival

    public ReachDetector() {
        super("Reach");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.isSpectator()) return;
        if (client.world == null) return;

        ClientWorld world = client.world;
        boolean isCreative = player.getAbilities().creativeMode;
        double maxReach = isCreative ? CREATIVE_MAX_REACH : FLAG_REACH;

        // Check if this player hit any other nearby player last tick
        // We detect by observing hurtTime transitions on nearby entities
        List<AbstractClientPlayerEntity> nearby = world.getPlayers()
                .stream()
                .filter(p -> !p.equals(player) && !p.equals(client.player))
                .filter(p -> p.hurtTime > 0) // recently damaged
                .toList();

        for (AbstractClientPlayerEntity victim : nearby) {
            double dist = player.distanceTo(victim);

            if (dist > data.maxReachSeen) {
                data.maxReachSeen = dist;
            }

            if (dist > maxReach) {
                data.reachViolations++;
                data.addFlag("Reach");

                if (data.canAlert("Reach")) {
                    int sev = dist > maxReach + 1.0 ? AlertUtils.HIGH : AlertUtils.MEDIUM;
                    AlertUtils.sendAlert(client, data.name, "Reach",
                            String.format("dist=%.2f max=%.2f", dist, maxReach),
                            sev, data.reachViolations);
                }
            }
        }
    }
}
