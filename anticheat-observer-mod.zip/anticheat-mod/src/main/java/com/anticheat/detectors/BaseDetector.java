package com.anticheat.detectors;

import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public abstract class BaseDetector {

    protected final String name;

    public BaseDetector(String name) {
        this.name = name;
    }

    /**
     * Called every client tick for each tracked player.
     */
    public abstract void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data);

    public String getName() {
        return name;
    }
}
