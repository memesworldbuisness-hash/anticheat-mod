package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class HitDelayDetector extends BaseDetector {

    // Vanilla 1.9+ hit cooldown = 20 ticks = 1000ms. Sustained <400ms avg = bypass
    private static final long   MIN_LEGIT_INTERVAL_MS = 400;
    private static final int    SAMPLE_SIZE           = 5;

    public HitDelayDetector() {
        super("HitDelay");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.isSpectator()) return;
        if (data.attackTimestamps.size() < SAMPLE_SIZE) return;

        Long[] times = data.attackTimestamps.toArray(new Long[0]);
        int fastIntervals = 0;

        for (int i = times.length - 1; i >= 1 && i >= times.length - SAMPLE_SIZE; i--) {
            long interval = times[i] - times[i - 1];
            if (interval < MIN_LEGIT_INTERVAL_MS && interval > 0) {
                fastIntervals++;
            }
        }

        if (fastIntervals >= 3) {
            data.addFlag("HitDelay");
            if (data.canAlert("HitDelay")) {
                AlertUtils.sendAlert(client, data.name, "HitDelay",
                        String.format("fastIntervals=%d (<%dms)", fastIntervals, MIN_LEGIT_INTERVAL_MS),
                        AlertUtils.HIGH, data.getFlagCount("HitDelay"));
            }
        }
    }
}
