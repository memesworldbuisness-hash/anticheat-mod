package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.MathUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

import java.util.ArrayDeque;
import java.util.Deque;

public class AimAssistDetector extends BaseDetector {

    // Suspiciously smooth rotation: very consistent yaw delta per tick
    private static final float  MAX_SMOOTH_VARIANCE = 0.5f;
    private static final int    SMOOTH_SAMPLE_SIZE  = 10;
    // Snapping: large instant rotation in one tick with no follow-through
    private static final float  SNAP_YAW_THRESHOLD  = 45f;

    public AimAssistDetector() {
        super("AimAssist");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.isSpectator()) return;
        if (data.rotationHistory.size() < SMOOTH_SAMPLE_SIZE) return;

        float[] rotations = new float[data.rotationHistory.size()];
        int i = 0;
        for (float[] r : data.rotationHistory) {
            rotations[i++] = r[0]; // yaw only
        }

        // --- Check 1: Unnaturally smooth yaw movement (aim assist glide) ---
        Deque<Double> deltas = new ArrayDeque<>();
        for (int j = 1; j < rotations.length; j++) {
            deltas.add((double) MathUtils.yawDifference(rotations[j], rotations[j - 1]));
        }
        double stdDev = MathUtils.standardDeviation(deltas);
        double mean   = deltas.stream().mapToDouble(Double::doubleValue).average().orElse(0);

        // Very smooth, consistent rotation with meaningful movement = aim assist
        if (stdDev < MAX_SMOOTH_VARIANCE && mean > 1.0f && mean < 15.0f) {
            boolean recentAttack = (System.currentTimeMillis() - data.lastAttackTime) < 500;
            if (recentAttack) {
                data.killauraViolations++;
                data.addFlag("AimAssist");
                if (data.canAlert("AimAssist")) {
                    AlertUtils.sendAlert(client, data.name, "AimAssist",
                            String.format("smoothRotSD=%.3f mean=%.2f°/t", stdDev, mean),
                            AlertUtils.MEDIUM, data.getFlagCount("AimAssist"));
                }
            }
        }

        // --- Check 2: Instant snap to target then freeze ---
        float[] last2 = data.rotationHistory.peekLast();
        float[] prev  = null;
        int idx = 0;
        for (float[] r : data.rotationHistory) {
            if (idx == data.rotationHistory.size() - 2) { prev = r; break; }
            idx++;
        }

        if (last2 != null && prev != null) {
            float snapYaw = MathUtils.yawDifference(last2[0], prev[0]);
            if (snapYaw > SNAP_YAW_THRESHOLD) {
                data.addFlag("AimAssist");
                if (data.canAlert("AimAssist")) {
                    AlertUtils.sendAlert(client, data.name, "AimAssist",
                            String.format("snapYaw=%.1f°", snapYaw),
                            AlertUtils.HIGH, data.getFlagCount("AimAssist"));
                }
            }
        }
    }
}
