package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

public class JesusDetector extends BaseDetector {

    private static final int WATER_SURFACE_TICK_LIMIT = 10;

    public JesusDetector() {
        super("Jesus");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.isSpectator()) return;
        if (player.getAbilities().flying) return;
        if (player.hasStatusEffect(StatusEffects.SLOW_FALLING)) return;

        boolean inWater = player.isTouchingWater();
        boolean onGround = player.isOnGround();
        double deltaY = player.getY() - data.lastY;

        // Jesus: player is "on top of" water — in water but not sinking
        if (inWater && onGround) {
            data.waterSurfaceTicks++;
        } else if (inWater && !onGround && Math.abs(deltaY) < 0.01) {
            // Hovering just at water surface
            data.waterSurfaceTicks++;
        } else {
            data.waterSurfaceTicks = Math.max(0, data.waterSurfaceTicks - 2);
        }

        if (data.waterSurfaceTicks > WATER_SURFACE_TICK_LIMIT) {
            data.jesusViolations++;
            data.addFlag("Jesus");
            if (data.canAlert("Jesus")) {
                AlertUtils.sendAlert(client, data.name, "Jesus",
                        String.format("waterSurfTicks=%d", data.waterSurfaceTicks),
                        AlertUtils.MEDIUM, data.jesusViolations);
            }
        }

        data.wasInWater = inWater;
    }
}
