package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

public class FlyDetector extends BaseDetector {

    // Vanilla max upward velocity without jump boost
    private static final double MAX_UPWARD_VELOCITY   = 0.42;
    // Vanilla gravity per tick
    private static final double GRAVITY               = 0.08;
    // Max ticks off ground before flagging (accounts for lag/jumps)
    private static final int    FLY_AIR_TICK_LIMIT    = 20;
    // VL threshold before alerting
    private static final int    VL_THRESHOLD_LOW      = 3;
    private static final int    VL_THRESHOLD_HIGH     = 10;

    public FlyDetector() {
        super("Fly");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.hasVehicle())         return; // riding boat/horse
        if (player.isSpectator())        return;
        if (player.getAbilities().flying) return; // creative/spectator allowed fly
        if (hasLevitation(player))       return; // levitation effect
        if (hasSlowFalling(player))      return;

        boolean onGround  = player.isOnGround();
        double  deltaY    = player.getY() - data.lastY;

        if (onGround) {
            data.airTicks = 0;
            data.groundTicks++;
        } else {
            data.airTicks++;
            data.groundTicks = 0;
        }

        // --- Check 1: Sustained Air (no gravity falling pattern) ---
        if (!onGround && data.airTicks > FLY_AIR_TICK_LIMIT) {
            // In vanilla, a player falling will always have increasing negative deltaY
            // A flyer tends to hover or move upward
            boolean isFalling = deltaY < -0.05;
            if (!isFalling || deltaY > 0.02) {
                data.flyViolations++;
                data.addFlag("Fly");
                if (data.canAlert("Fly")) {
                    int sev = data.flyViolations >= VL_THRESHOLD_HIGH
                            ? AlertUtils.HIGH : AlertUtils.MEDIUM;
                    AlertUtils.sendAlert(client, data.name, "Fly",
                            String.format("airTicks=%d dY=%.3f", data.airTicks, deltaY),
                            sev, data.flyViolations);
                }
            }
        }

        // --- Check 2: Upward movement while not on ground and no jump ---
        if (!onGround && deltaY > MAX_UPWARD_VELOCITY + 0.02 && !data.wasOnGround) {
            // Moved up more than a jump allows without being on ground last tick
            data.flyViolations++;
            data.addFlag("Fly");
            if (data.canAlert("Fly")) {
                AlertUtils.sendAlert(client, data.name, "Fly",
                        String.format("upward dY=%.3f max=%.3f", deltaY, MAX_UPWARD_VELOCITY),
                        AlertUtils.HIGH, data.flyViolations);
            }
        }

        // --- Check 3: Glide (very slow fall, no slow falling effect) ---
        if (!onGround && data.airTicks > 10 && deltaY > -0.005 && deltaY < 0.005) {
            // Hovering in place
            data.flyViolations++;
            data.addFlag("Fly");
            if (data.canAlert("Fly")) {
                AlertUtils.sendAlert(client, data.name, "Fly",
                        String.format("hover dY=%.4f airTicks=%d", deltaY, data.airTicks),
                        AlertUtils.HIGH, data.flyViolations);
            }
        }

        data.wasOnGround = onGround;
    }

    private boolean hasLevitation(AbstractClientPlayerEntity player) {
        return player.hasStatusEffect(StatusEffects.LEVITATION);
    }

    private boolean hasSlowFalling(AbstractClientPlayerEntity player) {
        return player.hasStatusEffect(StatusEffects.SLOW_FALLING);
    }
}
