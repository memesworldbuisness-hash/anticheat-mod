package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.MathUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

import java.util.ArrayDeque;
import java.util.Deque;

public class AutoClickerDetector extends BaseDetector {

    // Humanly impossible sustained CPS thresholds
    private static final double MAX_HUMAN_CPS      = 16.0;
    private static final double BUTTERFLY_CPS      = 22.0; // butterfly clicking threshold
    // GCD threshold — autoclickers produce near-perfect intervals (low GCD variance)
    private static final long   MIN_HUMAN_INTERVAL = 30; // ms — below this is suspicious
    private static final int    VL_THRESHOLD       = 5;

    // Per-player interval tracking (held outside PlayerData for detector-local use)
    // We use PlayerData.attackTimestamps instead

    public AutoClickerDetector() {
        super("AutoClicker");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.isSpectator()) return;

        long now = System.currentTimeMillis();

        // Only analyse if we have enough samples
        if (data.attackTimestamps.size() < 6) return;

        Long[] times = data.attackTimestamps.toArray(new Long[0]);

        // --- Check 1: CPS over 1 second ---
        long recentCount = 0;
        for (Long t : times) {
            if (now - t <= 1000L) recentCount++;
        }
        double cps = recentCount;

        if (cps > MAX_HUMAN_CPS) {
            data.autoClickerViolations++;
            data.addFlag("AutoClicker");
            if (data.canAlert("AutoClicker")) {
                int sev = cps > BUTTERFLY_CPS ? AlertUtils.HIGH : AlertUtils.MEDIUM;
                AlertUtils.sendAlert(client, data.name, "AutoClicker",
                        String.format("CPS=%.1f max=%.0f", cps, MAX_HUMAN_CPS),
                        sev, data.autoClickerViolations);
            }
        }

        // --- Check 2: GCD Analysis (machine-perfect intervals) ---
        // Compute deltas between consecutive attack timestamps
        long[] deltas = new long[times.length - 1];
        for (int i = 0; i < deltas.length; i++) {
            deltas[i] = Math.abs(times[i + 1] - times[i]);
        }

        long gcd = MathUtils.gcdsOfDeltas(deltas);

        // A GCD of 1 or perfect multiples of small numbers suggests timer-based clicking
        // Human clicking has high variance; autoclickers have low variance
        double variance = computeVariance(deltas);

        // Very low variance + reasonable CPS = likely autoclicker
        if (variance < 5.0 && cps >= 8.0) {
            data.autoClickerViolations++;
            data.addFlag("AutoClicker");
            if (data.canAlert("AutoClicker")) {
                AlertUtils.sendAlert(client, data.name, "AutoClicker",
                        String.format("lowVariance=%.2fms CPS=%.1f", variance, cps),
                        AlertUtils.HIGH, data.autoClickerViolations);
            }
        }

        // --- Check 3: Sub-human interval ---
        int subHumanCount = 0;
        for (long d : deltas) {
            if (d < MIN_HUMAN_INTERVAL) subHumanCount++;
        }
        if (subHumanCount >= 3) {
            data.autoClickerViolations++;
            data.addFlag("AutoClicker");
            if (data.canAlert("AutoClicker")) {
                AlertUtils.sendAlert(client, data.name, "AutoClicker",
                        String.format("subHumanInterval x%d (<=%dms)", subHumanCount, MIN_HUMAN_INTERVAL),
                        AlertUtils.HIGH, data.autoClickerViolations);
            }
        }

        // Decay
        if (data.autoClickerViolations > 0 && cps < 8.0) {
            data.autoClickerViolations = Math.max(0, data.autoClickerViolations - 1);
        }
    }

    private double computeVariance(long[] deltas) {
        if (deltas.length == 0) return Double.MAX_VALUE;
        double mean = 0;
        for (long d : deltas) mean += d;
        mean /= deltas.length;
        double variance = 0;
        for (long d : deltas) variance += (d - mean) * (d - mean);
        return Math.sqrt(variance / deltas.length);
    }
}
