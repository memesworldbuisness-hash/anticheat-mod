package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;

public class NoFallDetector extends BaseDetector {

    // Must fall at least this far to expect damage
    private static final double FALL_THRESHOLD = 3.5; // blocks
    // Minimum health drop we'd expect (rough estimate)
    private static final float  MIN_EXPECTED_DAMAGE = 0.5f;

    public NoFallDetector() {
        super("NoFall");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.isSpectator()) return;
        if (player.getAbilities().flying) return;
        if (player.hasStatusEffect(StatusEffects.SLOW_FALLING)) return;
        if (player.hasStatusEffect(StatusEffects.LEVITATION)) return;

        boolean onGround = player.isOnGround();
        double  deltaY   = player.getY() - data.lastY;

        // Track fall distance manually (client-side fallDistance can lag)
        if (!onGround && deltaY < 0) {
            data.lastDeltaY += Math.abs(deltaY);
        }

        // On landing: evaluate if they should have taken damage
        if (onGround && !data.wasOnGround) {
            double fallDist = data.lastDeltaY;

            if (fallDist > FALL_THRESHOLD) {
                // Expect some health to drop — we can't read their exact health change
                // But if they land from a HIGH fall and health doesn't move, flag
                // We track health indirectly: if they have full/near-full health after big fall
                float health = player.getHealth();

                // Only flag if fall was significant and they appear to have full health
                // (Rough heuristic — feather falling IV negates up to ~30 blocks)
                boolean hasFeatherFalling = hasFeatherFalling(player);
                if (!hasFeatherFalling && fallDist > 10.0 && health > 18.0f) {
                    data.noFallViolations++;
                    data.addFlag("NoFall");
                    if (data.canAlert("NoFall")) {
                        AlertUtils.sendAlert(client, data.name, "NoFall",
                                String.format("fall=%.1f blocks hp=%.1f", fallDist, health),
                                AlertUtils.HIGH, data.noFallViolations);
                    }
                }
            }

            data.lastDeltaY = 0;
        }

        data.wasOnGround = onGround;
    }

    private boolean hasFeatherFalling(AbstractClientPlayerEntity player) {
        // Check boots enchantment — we can read equipped items client-side
        var boots = player.getInventory().getArmorStack(0); // boots slot
        if (boots.isEmpty()) return false;
        var enchants = boots.getEnchantments();
        // Check for feather_falling key
        return enchants.toString().contains("feather_falling");
    }
}
