package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class NoKnockbackDetector extends BaseDetector {

    // If a player was hit but their velocity barely changed, flag
    private static final double MIN_EXPECTED_KNOCKBACK = 0.08; // blocks per tick
    private static final long   KNOCKBACK_WINDOW_MS    = 200;  // check within 200ms of being hit

    public NoKnockbackDetector() {
        super("NoKnockback");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.isSpectator()) return;

        // hurtTime is set to 10 when a player takes damage, counts down each tick
        // We catch the moment they JUST got hit (hurtTime == 10 or 9)
        if (player.hurtTime >= 9) {
            long now = System.currentTimeMillis();
            data.knockbackAppliedAt = now;

            // Record current velocity as baseline
            double velX = player.getVelocity().x;
            double velZ = player.getVelocity().z;
            data.expectedKnockback = new double[]{velX, velZ};
        }

        // Check ~3 ticks after hit whether they moved as expected
        if (data.expectedKnockback != null) {
            long now = System.currentTimeMillis();
            long elapsed = now - data.knockbackAppliedAt;

            if (elapsed > 50 && elapsed < KNOCKBACK_WINDOW_MS) {
                double velX = player.getVelocity().x;
                double velZ = player.getVelocity().z;
                double speed = Math.sqrt(velX * velX + velZ * velZ);

                if (speed < MIN_EXPECTED_KNOCKBACK) {
                    data.noKnockbackViolations++;
                    data.addFlag("NoKnockback");
                    if (data.canAlert("NoKnockback")) {
                        AlertUtils.sendAlert(client, data.name, "NoKnockback",
                                String.format("vel=%.4f expected>%.2f", speed, MIN_EXPECTED_KNOCKBACK),
                                AlertUtils.HIGH, data.noKnockbackViolations);
                    }
                }

                data.expectedKnockback = null;
            }
        }
    }
}
