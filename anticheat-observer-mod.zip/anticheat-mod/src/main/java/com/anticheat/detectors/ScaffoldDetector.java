package com.anticheat.detectors;

import com.anticheat.utils.AlertUtils;
import com.anticheat.utils.PlayerData;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

public class ScaffoldDetector extends BaseDetector {

    // Legit bridging: ~4-6 blocks/sec max for skilled players
    private static final int    MAX_BLOCKS_PER_SECOND = 8;
    // Scaffold places blocks beneath feet while moving — pitch check
    private static final float  SCAFFOLD_PITCH_MIN    = 70f; // must look fairly down to place below
    private static final long   WINDOW_MS             = 1000L;

    public ScaffoldDetector() {
        super("Scaffold");
    }

    @Override
    public void check(MinecraftClient client, AbstractClientPlayerEntity player, PlayerData data) {
        if (player.isSpectator()) return;

        long now = System.currentTimeMillis();
        // Purge old timestamps
        data.blockPlaceTimestamps.removeIf(t -> now - t > WINDOW_MS);

        int placesLastSecond = data.blockPlaceTimestamps.size();

        // Check 1: Too many block placements per second
        if (placesLastSecond > MAX_BLOCKS_PER_SECOND) {
            data.scaffoldViolations++;
            data.addFlag("Scaffold");
            if (data.canAlert("Scaffold")) {
                AlertUtils.sendAlert(client, data.name, "Scaffold",
                        String.format("blocks/s=%d max=%d", placesLastSecond, MAX_BLOCKS_PER_SECOND),
                        AlertUtils.HIGH, data.scaffoldViolations);
            }
        }

        // Check 2: Scaffold pitch anomaly — placing blocks without looking down
        // A scaffolder placing below while looking forward is a strong signal
        if (placesLastSecond >= 3) {
            float pitch = player.getPitch();
            boolean movingHorizontally = data.lastDeltaXZ > 0.05;

            if (movingHorizontally && pitch < SCAFFOLD_PITCH_MIN && pitch > -30f) {
                data.scaffoldViolations++;
                data.addFlag("Scaffold");
                if (data.canAlert("Scaffold")) {
                    AlertUtils.sendAlert(client, data.name, "Scaffold",
                            String.format("placePitch=%.1f° (not looking down)", pitch),
                            AlertUtils.HIGH, data.scaffoldViolations);
                }
            }
        }

        if (data.scaffoldViolations > 0 && placesLastSecond == 0) {
            data.scaffoldViolations = Math.max(0, data.scaffoldViolations - 1);
        }
    }

    /** Called by DetectionManager mixin when a block-place packet is observed */
    public static void onBlockPlace(PlayerData data) {
        data.blockPlaceTimestamps.addLast(System.currentTimeMillis());
    }
}
