package com.anticheat.utils;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class AlertUtils {

    // Severity levels
    public static final int LOW    = 1;
    public static final int MEDIUM = 2;
    public static final int HIGH   = 3;

    /**
     * Sends a private alert only visible to the local player.
     * Never sent to server chat — purely client-side overlay on the chat HUD.
     */
    public static void sendAlert(MinecraftClient client, String playerName, String checkName,
                                  String detail, int severity, int vl) {
        if (client.player == null) return;

        String severityTag;
        Formatting nameColor;
        Formatting checkColor;

        switch (severity) {
            case HIGH -> {
                severityTag = "§c§l[!!]";
                nameColor   = Formatting.RED;
                checkColor  = Formatting.DARK_RED;
            }
            case MEDIUM -> {
                severityTag = "§e§l[!]";
                nameColor   = Formatting.YELLOW;
                checkColor  = Formatting.GOLD;
            }
            default -> {
                severityTag = "§7[?]";
                nameColor   = Formatting.GRAY;
                checkColor  = Formatting.DARK_GRAY;
            }
        }

        // Format:  [AC] [!!] PlayerName | KillAura | detail (VL: 12)
        String line = String.format(
            "§8[§cAC§8] %s §f%s%s §8| %s%s §8| §7%s §8(§cVL§8: §f%d§8)",
            severityTag,
            nameColor.toString(), playerName,
            checkColor.toString(), checkName,
            detail,
            vl
        );

        MutableText msg = Text.literal(line);
        client.player.sendMessage(msg, false);
    }

    /**
     * Sends a plain informational message (no severity colour logic).
     */
    public static void sendInfo(MinecraftClient client, String message) {
        if (client.player == null) return;
        client.player.sendMessage(Text.literal("§8[§cAC§8] §7" + message), false);
    }
}
