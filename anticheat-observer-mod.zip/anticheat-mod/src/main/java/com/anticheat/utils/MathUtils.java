package com.anticheat.utils;

import java.util.Deque;

public class MathUtils {

    /** Horizontal distance between two XZ positions */
    public static double horizontalDistance(double x1, double z1, double x2, double z2) {
        double dx = x2 - x1;
        double dz = z2 - z1;
        return Math.sqrt(dx * dx + dz * dz);
    }

    /** Clamp a value between min and max */
    public static double clamp(double val, double min, double max) {
        return Math.max(min, Math.min(max, val));
    }

    /** Standard deviation of a deque of doubles */
    public static double standardDeviation(Deque<Double> values) {
        if (values.size() < 2) return 0.0;
        double mean = values.stream().mapToDouble(Double::doubleValue).average().orElse(0);
        double variance = values.stream()
                .mapToDouble(v -> (v - mean) * (v - mean))
                .average()
                .orElse(0);
        return Math.sqrt(variance);
    }

    /** Wrap a yaw angle to [-180, 180] */
    public static float wrapYaw(float yaw) {
        while (yaw > 180f)  yaw -= 360f;
        while (yaw < -180f) yaw += 360f;
        return yaw;
    }

    /** Absolute difference between two yaw angles (handles wrap) */
    public static float yawDifference(float yaw1, float yaw2) {
        float diff = Math.abs(wrapYaw(yaw1) - wrapYaw(yaw2));
        if (diff > 180f) diff = 360f - diff;
        return diff;
    }

    /** GCD of two longs — used for AutoClicker timer analysis */
    public static long gcd(long a, long b) {
        a = Math.abs(a);
        b = Math.abs(b);
        while (b != 0) {
            long t = b;
            b = a % b;
            a = t;
        }
        return a;
    }

    /**
     * Computes the GCD of a series of deltas, useful to detect
     * suspiciously regular click intervals (autoclicker signature).
     */
    public static long gcdsOfDeltas(long[] deltas) {
        if (deltas.length == 0) return 0;
        long g = deltas[0];
        for (int i = 1; i < deltas.length; i++) {
            g = gcd(g, deltas[i]);
            if (g <= 1) return 1;
        }
        return g;
    }
}
