package com.anticheat.utils;

import net.minecraft.entity.player.PlayerEntity;

import java.util.*;

public class PlayerData {

    public final UUID uuid;
    public final String name;

    // --- Position History ---
    public final Deque<double[]> positionHistory = new ArrayDeque<>(); // [x, y, z, timestamp]
    public static final int MAX_HISTORY = 40;

    // --- Movement ---
    public double lastX, lastY, lastZ;
    public double lastDeltaXZ, lastDeltaY;
    public boolean wasOnGround;
    public int airTicks = 0;
    public int groundTicks = 0;
    public int flyViolations = 0;
    public int speedViolations = 0;
    public int noFallViolations = 0;

    // --- KillAura ---
    public float lastYaw, lastPitch;
    public long lastAttackTime = 0;
    public int killauraViolations = 0;
    public int multiAuraViolations = 0;
    public final Deque<Long> attackTimestamps = new ArrayDeque<>(); // last N attack times
    public final Deque<float[]> rotationHistory = new ArrayDeque<>(); // [yaw, pitch]
    public static final int MAX_ROTATION_HISTORY = 20;
    public int invalidRotationStreak = 0;

    // --- AutoClicker / CPS ---
    public final Deque<Long> clickTimestamps = new ArrayDeque<>();
    public int autoClickerViolations = 0;
    public double lastCps = 0;

    // --- Reach ---
    public int reachViolations = 0;
    public double maxReachSeen = 0;

    // --- NoKnockback ---
    public double[] expectedKnockback = null; // {dx, dy, dz}
    public long knockbackAppliedAt = 0;
    public int noKnockbackViolations = 0;

    // --- Scaffold ---
    public int scaffoldViolations = 0;
    public int scaffoldBridgeTicks = 0;
    public final Deque<Long> blockPlaceTimestamps = new ArrayDeque<>();

    // --- Jesus / WaterWalk ---
    public int jesusViolations = 0;
    public boolean wasInWater = false;
    public int waterSurfaceTicks = 0;

    // --- Velocity ---
    public int velocityViolations = 0;

    // --- Flags ---
    public final Map<String, Integer> flagCounts = new LinkedHashMap<>();
    public final Map<String, Long> lastAlertTime = new HashMap<>();
    public static final long ALERT_COOLDOWN_MS = 4000;

    // --- General ---
    public long lastSeen = System.currentTimeMillis();
    public boolean isFlagged = false;

    public PlayerData(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    public void updatePosition(double x, double y, double z) {
        long now = System.currentTimeMillis();
        positionHistory.addLast(new double[]{x, y, z, now});
        if (positionHistory.size() > MAX_HISTORY) positionHistory.pollFirst();
        lastX = x;
        lastY = y;
        lastZ = z;
        lastSeen = now;
    }

    public void addRotation(float yaw, float pitch) {
        rotationHistory.addLast(new float[]{yaw, pitch});
        if (rotationHistory.size() > MAX_ROTATION_HISTORY) rotationHistory.pollFirst();
        lastYaw = yaw;
        lastPitch = pitch;
    }

    public void recordAttack() {
        long now = System.currentTimeMillis();
        attackTimestamps.addLast(now);
        // Keep last 20 attacks
        while (attackTimestamps.size() > 20) attackTimestamps.pollFirst();
        lastAttackTime = now;
    }

    public void recordClick() {
        long now = System.currentTimeMillis();
        clickTimestamps.addLast(now);
        // Keep last 2 seconds of clicks
        clickTimestamps.removeIf(t -> now - t > 2000);
    }

    public double getCps() {
        long now = System.currentTimeMillis();
        clickTimestamps.removeIf(t -> now - t > 1000);
        lastCps = clickTimestamps.size();
        return lastCps;
    }

    public void addFlag(String checkName) {
        flagCounts.merge(checkName, 1, Integer::sum);
        isFlagged = true;
    }

    public int getFlagCount(String checkName) {
        return flagCounts.getOrDefault(checkName, 0);
    }

    public boolean canAlert(String checkName) {
        long now = System.currentTimeMillis();
        Long last = lastAlertTime.get(checkName);
        if (last == null || now - last >= ALERT_COOLDOWN_MS) {
            lastAlertTime.put(checkName, now);
            return true;
        }
        return false;
    }

    public double distanceTo(PlayerEntity other) {
        double dx = other.getX() - lastX;
        double dy = other.getY() - lastY;
        double dz = other.getZ() - lastZ;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }
}
